library(testthat)
library(polyreg)

test_check("polyreg")
