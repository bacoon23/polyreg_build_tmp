## ---- fig.height = 5, fig.width = 6, fig.align = "center"----------------
library(polyreg)
plot_r(beerbowl)

